<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserController extends CI_Controller {

	public function Register()
	{
        // Nomor 4
        // Jika Password dan Re-Enter Password sama, maka:
        $pass1 = $this->input->post('pass');
        $pass2 = $this->input->post('re_pass');
        if($pass1 == $pass2){
            // Panggil fungsi Register pada model User
            $regis = $this->user->Register();
            if($regis) {
                // Jika Berhasil Register
                // Buat Flashdata dan arahkan kembali ke Landing
                $this->session->set_flashdata('success','Success Registrasi');
                redirect('Landing');
            } else {
                // Jika gagal
                // Buat Flashdata dan arahkan kembali ke Landing/Register
                $this->session->set_flashdata('failed', 'Gagal Registrasi');
                redirect('Landing/Register');
            }
        } else {
            // Jika Password berbeda
            // Buat flashdata
            // Arahkan kembali ke Landing/Register
            $this->session->set_flashdata('failed', 'Password Tidak Sama');
            redirect('Landing/Register');
        }
    }

    public function Signin() {
        // Nomor 7
        // Panggil fungsi findUser
        // Jika User ditemukan
        $cek = $this->User->findUser();
        if($cek != NULL){
            // Jika rememberme dicentang
            if($this->input->post('remember-me',true) == TRUE) {
                // Buatkan cookie dengan isi username
                // Arahkan kembali ke Landing
                $cookie = array(
                        'name'   => 'User',
                        'value'  => $cek['Username'],
                        'expire' => '86500',
                        'domain' => base_url(),
                        'path'   => '/',
                        'prefix' => 'myprefix_',
                        'secure' => TRUE
                );
                $this->input->set_cookie($cookie);
                redirect('Landing');
            } else {
                // Buatkan session dengan isi username
                // Arahkan kembali ke Landing
                $newdata = array(
                        'username'  => $cek['Username'],
                        'logged_in' => TRUE
                );
                $this->session->set_userdata($newdata);
                redirect('Landing/');
            }
        } else {
            // Jika data tidak ditemukan
            // maka buat flashdata yang menandakan data tidak ditemukan
            $this->session->set_flashdata('failed', 'Gagal Login');
            redirect('Landing');
        }
    }

    public function Logout() {
        $cookie = $this->input->cookie(NAMA_COOKIE);
        if(isset($cookie)) {
            delete_cookie(NAMA_COOKIE);
            redirect('Landing');
        } else {
            session_destroy();
            redirect('Landing');
        }
    }
}